import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// =====================================================
// SUPABASE CONFIGURATION
// =====================================================

const String supabaseUrl = 'https://ixafkneezwqldmiphlma.supabase.co';
const String supabaseKey = 'sb_publishable_yfFd7y6cAciu2apxY2y26w_H1Ih47-n';

const String authUrl = '$supabaseUrl/auth/v1';
const String eventsUrl = '$supabaseUrl/rest/v1/events';
const String messagesUrl = '$supabaseUrl/rest/v1/messages';
const String votesUrl = '$supabaseUrl/rest/v1/votes';

// =====================================================
// SESSION / AUTHENTICATION
// =====================================================

class Session {
  final String accessToken;
  final String userId;
  final String email;

  const Session({
    required this.accessToken,
    required this.userId,
    required this.email,
  });

  factory Session.fromJson(Map<String, dynamic> json) {
    final user = json['user'] as Map<String, dynamic>?;

    if (json['access_token'] == null || user == null) {
      throw Exception('Përgjigje e pavlefshme nga Supabase.');
    }

    return Session(
      accessToken: json['access_token'] as String,
      userId: user['id'] as String,
      email: user['email'] as String? ?? '',
    );
  }
}

Session? currentSession;

Map<String, String> authHeaders({
  bool preferRepresentation = false,
}) {
  final headers = <String, String>{
    'apikey': supabaseKey,
    'Authorization': 'Bearer ${currentSession?.accessToken ?? supabaseKey}',
    'Content-Type': 'application/json',
  };

  if (preferRepresentation) {
    headers['Prefer'] = 'return=representation';
  }

  return headers;
}

String responseError(http.Response response) {
  try {
    final data = jsonDecode(response.body);

    if (data is Map<String, dynamic>) {
      return (data['msg'] ??
              data['message'] ??
              data['error_description'] ??
              data['error'] ??
              'Gabim HTTP ${response.statusCode}')
          .toString();
    }
  } catch (_) {}

  return 'Gabim HTTP ${response.statusCode}: ${response.body}';
}

String authError(http.Response response) {
  return responseError(response);
}

Future<Session> signUp(String email, String password) async {
  final response = await http.post(
    Uri.parse('$authUrl/signup'),
    headers: authHeaders(),
    body: jsonEncode({
      'email': email,
      'password': password,
    }),
  );

  if (response.statusCode != 200 && response.statusCode != 201) {
    throw Exception(authError(response));
  }

  final data = jsonDecode(response.body) as Map<String, dynamic>;

  if (data['access_token'] == null) {
    throw Exception(
      'Llogaria u krijua. Konfirmoni email-in ose çaktivizoni konfirmimin në Supabase.',
    );
  }

  return Session.fromJson(data);
}

Future<Session> signIn(String email, String password) async {
  final response = await http.post(
    Uri.parse('$authUrl/token?grant_type=password'),
    headers: authHeaders(),
    body: jsonEncode({
      'email': email,
      'password': password,
    }),
  );

  if (response.statusCode != 200) {
    throw Exception(authError(response));
  }

  return Session.fromJson(
    jsonDecode(response.body) as Map<String, dynamic>,
  );
}

Future<void> signOut() async {
  if (currentSession == null) return;

  final response = await http.post(
    Uri.parse('$authUrl/logout'),
    headers: authHeaders(),
  );

  if (response.statusCode != 200 && response.statusCode != 204) {
    throw Exception(authError(response));
  }
}

// =====================================================
// EVENT MODEL & CRUD
// =====================================================

class Event {
  final int id;
  final String title;
  final String date;
  final String location;
  final int likes;
  final String? userId;
  final String? author;

  const Event({
    required this.id,
    required this.title,
    required this.date,
    required this.location,
    this.likes = 0,
    this.userId,
    this.author,
  });

  factory Event.fromJson(Map<String, dynamic> json) {
    return Event(
      id: (json['id'] as num).toInt(),
      title: json['title'] as String? ?? '',
      date: json['date'] as String? ?? '',
      location: json['location'] as String? ?? '',
      likes: (json['likes'] as num?)?.toInt() ?? 0,
      userId: json['user_id'] as String?,
      author: json['author'] as String?,
    );
  }

  bool get isMine => userId != null && userId == currentSession?.userId;
}

Future<List<Event>> fetchEvents({bool onlyMine = false}) async {
  final query = <String, String>{
    'select': '*',
    'order': 'id.asc',
  };

  if (onlyMine) {
    final session = currentSession;
    if (session == null) throw Exception('Duhet të kyçeni së pari.');
    query['user_id'] = 'eq.${session.userId}';
  }

  final uri = Uri.parse(eventsUrl).replace(queryParameters: query);
  final response = await http.get(uri, headers: authHeaders());

  if (response.statusCode != 200) {
    throw Exception(
        'Gabim gjatë marrjes së eventeve: ${responseError(response)}');
  }

  final data = jsonDecode(response.body) as List<dynamic>;
  return data
      .map((item) => Event.fromJson(item as Map<String, dynamic>))
      .toList();
}

Future<void> addEvent(String title, String date, String location) async {
  final session = currentSession;
  if (session == null) throw Exception('Duhet të kyçeni së pari.');

  final response = await http.post(
    Uri.parse(eventsUrl),
    headers: authHeaders(),
    body: jsonEncode({
      'title': title,
      'date': date,
      'location': location,
      'user_id': session.userId,
      'author': session.email,
      'likes': 0,
    }),
  );

  if (response.statusCode != 201 && response.statusCode != 200) {
    throw Exception(
        'Gabim gjatë shtimit të eventit: ${responseError(response)}');
  }
}

Future<void> likeEvent(int id, int currentLikes) async {
  final response = await http.patch(
    Uri.parse(eventsUrl).replace(queryParameters: {'id': 'eq.$id'}),
    headers: authHeaders(),
    body: jsonEncode({
      'likes': currentLikes + 1,
    }),
  );

  if (response.statusCode != 200 && response.statusCode != 204) {
    throw Exception(
        'Gabim gjatë votimit të eventit: ${responseError(response)}');
  }
}

Future<void> deleteEvent(int id) async {
  final response = await http.delete(
    Uri.parse(eventsUrl).replace(queryParameters: {'id': 'eq.$id'}),
    headers: authHeaders(),
  );

  if (response.statusCode != 204 && response.statusCode != 200) {
    throw Exception(
        'Gabim gjatë fshirjes së eventit: ${responseError(response)}');
  }
}

// =====================================================
// MESSAGE MODEL & API
// =====================================================

class Message {
  final int id;
  final String? userId;
  final String author;
  final String content;
  final DateTime createdAt;

  const Message({
    required this.id,
    this.userId,
    required this.author,
    required this.content,
    required this.createdAt,
  });

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: (json['id'] as num).toInt(),
      userId: json['user_id'] as String?,
      author: json['author'] as String? ?? 'BGT',
      content: json['content'] as String? ?? '',
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }

  bool get isMine => userId != null && userId == currentSession?.userId;
}

Future<List<Message>> fetchMessages() async {
  final response = await http.get(
    Uri.parse(messagesUrl).replace(
      queryParameters: {'select': '*', 'order': 'created_at.desc'},
    ),
    headers: authHeaders(),
  );

  if (response.statusCode != 200) {
    throw Exception(
        'Gabim gjatë marrjes së mesazheve: ${responseError(response)}');
  }

  final data = jsonDecode(response.body) as List<dynamic>;
  return data
      .map((item) => Message.fromJson(item as Map<String, dynamic>))
      .toList();
}

Future<void> sendMessage(String content) async {
  final session = currentSession;
  if (session == null) throw Exception('Duhet të kyçeni së pari.');

  final response = await http.post(
    Uri.parse(messagesUrl),
    headers: authHeaders(),
    body: jsonEncode({
      'user_id': session.userId,
      'author': session.email,
      'content': content,
    }),
  );

  if (response.statusCode != 201 && response.statusCode != 200) {
    throw Exception(
        'Gabim gjatë dërgimit të mesazhit: ${responseError(response)}');
  }
}

// =====================================================
// VOTES API (Sondazhet e Përdoruesve)
// =====================================================

Future<List<Map<String, dynamic>>> fetchVotes() async {
  final response = await http.get(
    Uri.parse(votesUrl).replace(queryParameters: {'select': '*'}),
    headers: authHeaders(),
  );

  if (response.statusCode != 200) {
    throw Exception(
        'Gabim gjatë marrjes së votave: ${responseError(response)}');
  }

  final data = jsonDecode(response.body) as List<dynamic>;
  return data.cast<Map<String, dynamic>>();
}

Future<void> createPollVote(String title, String option) async {
  final session = currentSession;
  if (session == null) throw Exception('Duhet të kyçeni së pari.');

  final response = await http.post(
    Uri.parse(votesUrl),
    headers: authHeaders(),
    body: jsonEncode({
      'user_id': session.userId,
      'option': '$title: $option',
    }),
  );

  if (response.statusCode != 201 && response.statusCode != 200) {
    final err = responseError(response);
    if (err.contains('unique constraint') ||
        err.contains('votes_user_id_key')) {
      throw Exception('Keni votuar më parë në këtë sondazh!');
    }
    throw Exception('Pati një gabim gjatë votimit: $err');
  }
}

// =====================================================
// MAIN APP
// =====================================================

enum AppLanguage { sq, en }

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ThemeMode _themeMode = ThemeMode.light;
  AppLanguage _language = AppLanguage.sq;

  void _onLogin(Session session) {
    setState(() {
      currentSession = session;
    });
  }

  Future<void> _logout() async {
    try {
      await signOut();
    } catch (_) {}

    if (!mounted) return;

    setState(() {
      currentSession = null;
    });
  }

  void _toggleTheme() {
    setState(() {
      _themeMode =
          _themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  void _toggleLanguage() {
    setState(() {
      _language = _language == AppLanguage.sq ? AppLanguage.en : AppLanguage.sq;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BGT Campus',
      debugShowCheckedModeBanner: false,
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorSchemeSeed: Colors.blue,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.blue,
      ),
      home: currentSession == null
          ? LoginPage(onLogin: _onLogin, isSq: _language == AppLanguage.sq)
          : HomeShell(
              onLogout: _logout,
              themeMode: _themeMode,
              onToggleTheme: _toggleTheme,
              language: _language,
              onToggleLanguage: _toggleLanguage,
            ),
    );
  }
}

class LoginPage extends StatefulWidget {
  final ValueChanged<Session> onLogin;
  final bool isSq;

  const LoginPage({super.key, required this.onLogin, required this.isSq});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _loading = false;
  bool _registerMode = false;
  String? _error;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  String? _validate(String email, String password) {
    if (!email.contains('@') || !email.contains('.')) {
      return widget.isSq
          ? 'Shkruani një email të vlefshëm.'
          : 'Enter a valid email.';
    }
    if (password.length < 6) {
      return widget.isSq
          ? 'Fjalëkalimi duhet të ketë së paku 6 karaktere.'
          : 'Password must be at least 6 characters.';
    }
    return null;
  }

  Future<void> _submit(bool isRegister) async {
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    final validationError = _validate(email, password);
    if (validationError != null) {
      setState(() => _error = validationError);
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final session = isRegister
          ? await signUp(email, password)
          : await signIn(email, password);
      if (!mounted) return;
      widget.onLogin(session);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isSq = widget.isSq;

    return Scaffold(
      appBar: AppBar(title: const Text('BGT Campus'), centerTitle: true),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.school, size: 76, color: Colors.blue),
              const SizedBox(height: 16),
              Text(
                _registerMode
                    ? (isSq ? 'Krijo llogari' : 'Create account')
                    : (isSq ? 'Mirë se vini!' : 'Welcome!'),
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: isSq ? 'Fjalëkalimi' : 'Password',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.lock),
                ),
              ),
              const SizedBox(height: 16),
              if (_error != null) ...[
                Text(_error!,
                    style:
                        TextStyle(color: Theme.of(context).colorScheme.error)),
                const SizedBox(height: 16),
              ],
              if (_loading)
                const CircularProgressIndicator()
              else ...[
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => _submit(_registerMode),
                    child: Text(_registerMode
                        ? (isSq ? 'Regjistrohu' : 'Register')
                        : (isSq ? 'Kyçu' : 'Login')),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      _registerMode = !_registerMode;
                      _error = null;
                    });
                  },
                  child: Text(
                    _registerMode
                        ? (isSq ? 'Ke llogari? Kyçu' : 'Have an account? Login')
                        : (isSq
                            ? 'Nuk ke llogari? Regjistrohu'
                            : 'Don\'t have an account? Register'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  final VoidCallback onLogout;
  final ThemeMode themeMode;
  final VoidCallback onToggleTheme;
  final AppLanguage language;
  final VoidCallback onToggleLanguage;

  const HomeShell({
    super.key,
    required this.onLogout,
    required this.themeMode,
    required this.onToggleTheme,
    required this.language,
    required this.onToggleLanguage,
  });

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final isSq = widget.language == AppLanguage.sq;

    final pages = [
      HomePage(isSq: isSq),
      EventsPage(isSq: isSq),
      VotesPage(isSq: isSq),
      ChatPage(isSq: isSq),
      ProfilePage(
        onLogout: widget.onLogout,
        themeMode: widget.themeMode,
        onToggleTheme: widget.onToggleTheme,
        language: widget.language,
        onToggleLanguage: widget.onToggleLanguage,
      ),
    ];

    return Scaffold(
      body: IndexedStack(index: _selectedIndex, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          setState(() => _selectedIndex = index);
        },
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.home), label: isSq ? 'Ballina' : 'Home'),
          NavigationDestination(
              icon: const Icon(Icons.event),
              label: isSq ? 'Eventet' : 'Events'),
          NavigationDestination(
              icon: const Icon(Icons.how_to_vote),
              label: isSq ? 'Sondazhet' : 'Polls'),
          NavigationDestination(icon: const Icon(Icons.chat), label: 'Chat'),
          NavigationDestination(
              icon: const Icon(Icons.person),
              label: isSq ? 'Profili' : 'Profile'),
        ],
      ),
    );
  }
}

// =====================================================
// HOME PAGE (Me Evente dhe Sondazhe Live)
// =====================================================

class HomePage extends StatefulWidget {
  final bool isSq;
  const HomePage({super.key, required this.isSq});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<Event>> _eventsFuture;
  late Future<List<Map<String, dynamic>>> _votesFuture;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    setState(() {
      _eventsFuture = fetchEvents();
      _votesFuture = fetchVotes();
    });
  }

  Future<void> _handleLike(Event event) async {
    try {
      await likeEvent(event.id, event.likes);
      _reload();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Gabim: $e')));
    }
  }

  Future<void> _handlePollVote(String pollTitle, String option) async {
    final isSq = widget.isSq;
    try {
      await createPollVote(pollTitle, option);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text(isSq ? 'Vota u dërgua me sukses!' : 'Vote submitted!')),
      );
      _reload();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isSq = widget.isSq;

    return Scaffold(
      appBar: AppBar(
        title: Text(isSq ? 'Ballina' : 'Home'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _reload),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          _reload();
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(isSq ? 'Mirë se vini!' : 'Welcome!',
                  style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 4),
              Text(currentSession?.email ?? '',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(color: Colors.blue)),
              const SizedBox(height: 20),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.school, size: 36),
                  title: const Text('BGT Campus'),
                  subtitle: Text(isSq
                      ? 'Eventet, komunikimi dhe aktivitetet e kampusit.'
                      : 'Events, communication and campus activities.'),
                ),
              ),
              const SizedBox(height: 24),

              // ================= SONDAZHET NË BALLINË =================
              Text(isSq ? 'Sondazhet Aktive' : 'Active Polls',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              FutureBuilder<List<Map<String, dynamic>>>(
                future: _votesFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                        child: Padding(
                            padding: EdgeInsets.all(12),
                            child: CircularProgressIndicator()));
                  }
                  if (snapshot.hasError) {
                    return Text(isSq
                        ? 'Gabim gjatë marrjes së sondazheve.'
                        : 'Error loading polls.');
                  }
                  final votes = snapshot.data ?? [];
                  if (votes.isEmpty) {
                    return Text(
                        isSq ? 'Nuk ka sondazhe aktive.' : 'No active polls.');
                  }

                  Map<String, int> counts = {};
                  for (var v in votes) {
                    String opt = v['option'] ?? 'N/A';
                    counts[opt] = (counts[opt] ?? 0) + 1;
                  }

                  return ListView(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: counts.entries.map((entry) {
                      return Card(
                        color: Colors.blue.shade50,
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading:
                              const Icon(Icons.how_to_vote, color: Colors.blue),
                          title: Text(entry.key,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w600)),
                          trailing: Text(
                            '${entry.value} ${isSq ? "vota" : "votes"}',
                            style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.blue),
                          ),
                          onTap: () {
                            List<String> parts = entry.key.split(': ');
                            if (parts.length == 2) {
                              _handlePollVote(parts[0], parts[1]);
                            }
                          },
                        ),
                      );
                    }).toList(),
                  );
                },
              ),

              const SizedBox(height: 24),

              // ================= EVENTET NË BALLINË =================
              Text(isSq ? 'Eventet e fundit' : 'Recent Events',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              FutureBuilder<List<Event>>(
                future: _eventsFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                        child: Padding(
                            padding: EdgeInsets.all(20),
                            child: CircularProgressIndicator()));
                  }
                  if (snapshot.hasError) {
                    return Text(isSq
                        ? 'Gabim gjatë marrjes së eventeve.'
                        : 'Error loading events.');
                  }
                  final events = snapshot.data ?? [];
                  if (events.isEmpty) {
                    return Text(
                        isSq ? 'Nuk ka evente.' : 'No events available.');
                  }
                  return ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: events.length,
                    itemBuilder: (context, index) {
                      final event = events[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading:
                              Icon(event.isMine ? Icons.person : Icons.event),
                          title: Text(event.title),
                          subtitle: Text('${event.date} • ${event.location}'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.favorite,
                                    color: Colors.red),
                                onPressed: () => _handleLike(event),
                              ),
                              Text('${event.likes}'),
                            ],
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => EventDetailPage(
                                      event: event, isSq: isSq)),
                            );
                          },
                        ),
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class EventsPage extends StatefulWidget {
  final bool isSq;
  const EventsPage({super.key, required this.isSq});

  @override
  State<EventsPage> createState() => _EventsPageState();
}

class _EventsPageState extends State<EventsPage> {
  late Future<List<Event>> _future;
  final _titleController = TextEditingController();
  final _dateController = TextEditingController();
  final _locationController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _future = fetchEvents();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _dateController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  void _reload() {
    setState(() => _future = fetchEvents());
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _handleLike(Event event) async {
    try {
      await likeEvent(event.id, event.likes);
      _reload();
    } catch (e) {
      _showMessage('${widget.isSq ? "Gabim" : "Error"}: $e');
    }
  }

  Future<void> _confirmDelete(Event event) async {
    final isSq = widget.isSq;
    if (!event.isMine) {
      _showMessage(isSq
          ? 'Mund të fshini vetëm eventet tuaja.'
          : 'You can only delete your own events.');
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(isSq ? 'Fshij eventin' : 'Delete event'),
        content: Text(isSq
            ? 'A jeni të sigurt që dëshironi ta fshini "${event.title}"?'
            : 'Are you sure you want to delete "${event.title}"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(isSq ? 'Anulo' : 'Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(isSq ? 'Fshij' : 'Delete')),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await deleteEvent(event.id);
      if (!mounted) return;
      _reload();
      _showMessage(isSq ? 'Eventi u fshi.' : 'Event deleted.');
    } catch (e) {
      _showMessage('${isSq ? "Gabim" : "Error"}: $e');
    }
  }

  Future<void> _showAddDialog() async {
    final isSq = widget.isSq;
    _titleController.clear();
    _dateController.clear();
    _locationController.clear();

    final formKey = GlobalKey<FormState>();

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(isSq ? 'Event i ri' : 'New Event'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration:
                      InputDecoration(labelText: isSq ? 'Titulli' : 'Title'),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? (isSq ? 'Shkruani titullin.' : 'Enter title.')
                      : null,
                ),
                TextFormField(
                  controller: _dateController,
                  decoration: InputDecoration(
                      labelText: isSq ? 'Data' : 'Date',
                      hintText: '2026-10-09'),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? (isSq ? 'Shkruani datën.' : 'Enter date.')
                      : null,
                ),
                TextFormField(
                  controller: _locationController,
                  decoration:
                      InputDecoration(labelText: isSq ? 'Vendi' : 'Location'),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? (isSq ? 'Shkruani vendin.' : 'Enter location.')
                      : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(isSq ? 'Anulo' : 'Cancel')),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate())
                Navigator.pop(dialogContext, true);
            },
            child: Text(isSq ? 'Ruaj' : 'Save'),
          ),
        ],
      ),
    );

    if (saved != true) return;

    try {
      await addEvent(_titleController.text.trim(), _dateController.text.trim(),
          _locationController.text.trim());
      if (!mounted) return;
      _reload();
      _showMessage(
          isSq ? 'Eventi u shtua me sukses.' : 'Event added successfully.');
    } catch (e) {
      _showMessage('${isSq ? "Gabim" : "Error"}: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isSq = widget.isSq;

    return Scaffold(
      appBar: AppBar(title: Text(isSq ? 'BGT Eventet' : 'BGT Events')),
      body: FutureBuilder<List<Event>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.cloud_off, size: 60),
                  const SizedBox(height: 16),
                  Text(
                      '${isSq ? "Nuk u ngarkuan eventet" : "Failed to load events"}.\n${snapshot.error}',
                      textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  FilledButton(
                      onPressed: _reload,
                      child: Text(isSq ? 'Provo përsëri' : 'Try again')),
                ],
              ),
            );
          }
          final events = snapshot.data ?? [];
          if (events.isEmpty)
            return Center(
                child: Text(isSq ? 'Nuk ka evente ende.' : 'No events yet.'));

          return RefreshIndicator(
            onRefresh: () async {
              _reload();
            },
            child: ListView.builder(
              itemCount: events.length,
              itemBuilder: (context, index) {
                final event = events[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: ListTile(
                    leading: Icon(event.isMine ? Icons.person : Icons.event),
                    title: Text(event.title),
                    subtitle: Text(
                        '${event.date} • ${event.location}\n${isSq ? "Postuar nga" : "Posted by"}: ${event.author ?? "BGT"}'),
                    isThreeLine: true,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.favorite, color: Colors.red),
                          onPressed: () => _handleLike(event),
                        ),
                        Text('${event.likes}'),
                        const SizedBox(width: 8),
                        IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => _confirmDelete(event)),
                      ],
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  EventDetailPage(event: event, isSq: isSq)));
                    },
                  ),
                );
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddDialog,
        icon: const Icon(Icons.add),
        label: Text(isSq ? 'Shto event' : 'Add event'),
      ),
    );
  }
}

class VotesPage extends StatefulWidget {
  final bool isSq;
  const VotesPage({super.key, required this.isSq});

  @override
  State<VotesPage> createState() => _VotesPageState();
}

class _VotesPageState extends State<VotesPage> {
  late Future<List<Map<String, dynamic>>> _votesFuture;

  final _titleController = TextEditingController();
  final _optAController = TextEditingController();
  final _optBController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _optAController.dispose();
    _optBController.dispose();
    super.dispose();
  }

  void _reload() {
    setState(() {
      _votesFuture = fetchVotes();
    });
  }

  Future<void> _vote(String pollTitle, String option) async {
    final isSq = widget.isSq;
    try {
      await createPollVote(pollTitle, option);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text(isSq ? 'Vota u dërgua me sukses!' : 'Vote submitted!')),
      );
      _reload();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _showCreatePollDialog() async {
    final isSq = widget.isSq;
    _titleController.clear();
    _optAController.clear();
    _optBController.clear();

    final formKey = GlobalKey<FormState>();

    final created = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(isSq ? 'Krijo Sondazh të ri' : 'Create New Poll'),
        content: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: InputDecoration(
                      labelText: isSq ? 'Titulli i Pyetjes' : 'Poll Question'),
                  validator: (v) => v == null || v.trim().isEmpty
                      ? (isSq ? 'Shkruani pyetjen.' : 'Enter question.')
                      : null,
                ),
                TextFormField(
                  controller: _optAController,
                  decoration: InputDecoration(
                      labelText: isSq ? 'Opsioni 1' : 'Option 1'),
                  validator: (v) => v == null || v.trim().isEmpty
                      ? (isSq ? 'Shkruani opsionin.' : 'Enter option.')
                      : null,
                ),
                TextFormField(
                  controller: _optBController,
                  decoration: InputDecoration(
                      labelText: isSq ? 'Opsioni 2' : 'Option 2'),
                  validator: (v) => v == null || v.trim().isEmpty
                      ? (isSq ? 'Shkruani opsionin.' : 'Enter option.')
                      : null,
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(isSq ? 'Anulo' : 'Cancel')),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate())
                Navigator.pop(dialogContext, true);
            },
            child: Text(isSq ? 'Krijo & Voto' : 'Create & Vote'),
          ),
        ],
      ),
    );

    if (created != true) return;

    await _vote(_titleController.text.trim(), _optAController.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    final isSq = widget.isSq;

    return Scaffold(
      appBar: AppBar(
        title: Text(isSq ? 'Sondazhet & Votimet' : 'Polls & Votes'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _reload),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: FutureBuilder<List<Map<String, dynamic>>>(
                future: _votesFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Text(
                        '${isSq ? "Gabim" : "Error"}: ${snapshot.error}');
                  }
                  final votes = snapshot.data ?? [];
                  if (votes.isEmpty) {
                    return Center(
                      child: Text(isSq
                          ? 'Nuk ka sondazhe ende. Shtypni + për të krijuar.'
                          : 'No polls yet. Tap + to create.'),
                    );
                  }

                  Map<String, int> counts = {};
                  for (var v in votes) {
                    String opt = v['option'] ?? 'N/A';
                    counts[opt] = (counts[opt] ?? 0) + 1;
                  }

                  return ListView(
                    children: counts.entries.map((entry) {
                      return Card(
                        child: ListTile(
                          title: Text(entry.key),
                          trailing: Text(
                            '${entry.value} ${isSq ? "vota" : "votes"}',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          onTap: () {
                            List<String> parts = entry.key.split(': ');
                            if (parts.length == 2) {
                              _vote(parts[0], parts[1]);
                            }
                          },
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreatePollDialog,
        icon: const Icon(Icons.add),
        label: Text(isSq ? 'Krijo Sondazh' : 'New Poll'),
      ),
    );
  }
}

class EventDetailPage extends StatelessWidget {
  final Event event;
  final bool isSq;

  const EventDetailPage({super.key, required this.event, required this.isSq});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(event.title)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(event.title,
                style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 20),
            ListTile(
                leading: const Icon(Icons.calendar_month),
                title: Text(isSq ? 'Data' : 'Date'),
                subtitle: Text(event.date)),
            ListTile(
                leading: const Icon(Icons.location_on),
                title: Text(isSq ? 'Vendi' : 'Location'),
                subtitle: Text(event.location)),
            ListTile(
                leading: const Icon(Icons.favorite, color: Colors.red),
                title: Text(isSq ? 'Pëlqime' : 'Likes'),
                subtitle: Text('${event.likes}')),
            ListTile(
                leading: const Icon(Icons.person),
                title: Text(isSq ? 'Postuar nga' : 'Posted by'),
                subtitle: Text(event.author ?? 'BGT')),
          ],
        ),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final VoidCallback onLogout;
  final ThemeMode themeMode;
  final VoidCallback onToggleTheme;
  final AppLanguage language;
  final VoidCallback onToggleLanguage;

  const ProfilePage({
    super.key,
    required this.onLogout,
    required this.themeMode,
    required this.onToggleTheme,
    required this.language,
    required this.onToggleLanguage,
  });

  @override
  Widget build(BuildContext context) {
    final email = currentSession?.email ?? 'N/A';
    final initial = email.isNotEmpty ? email[0].toUpperCase() : '?';
    final isSq = language == AppLanguage.sq;
    final isDark = themeMode == ThemeMode.dark;

    return Scaffold(
      appBar: AppBar(title: Text(isSq ? 'Profili' : 'Profile')),
      body: ListView(
        children: [
          const SizedBox(height: 24),
          Center(
            child: CircleAvatar(
                radius: 40,
                child: Text(initial, style: const TextStyle(fontSize: 32))),
          ),
          const SizedBox(height: 12),
          Center(
              child:
                  Text(email, style: Theme.of(context).textTheme.titleMedium)),
          const SizedBox(height: 24),
          const Divider(),
          ListTile(
            leading: Icon(isDark ? Icons.dark_mode : Icons.light_mode),
            title: Text(isSq ? 'Mënyra e errët (Dark Mode)' : 'Dark Mode'),
            trailing: Switch(value: isDark, onChanged: (_) => onToggleTheme()),
          ),
          ListTile(
            leading: const Icon(Icons.language),
            title: Text(isSq ? 'Gjuha / Language' : 'Language / Gjuha'),
            trailing: TextButton(
              onPressed: onToggleLanguage,
              child: Text(isSq ? 'SQ ➔ EN' : 'EN ➔ SQ',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.list_alt),
            title: Text(isSq ? 'Postimet e mia' : 'My Posts'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => MyEventsPage(isSq: isSq)));
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: Text(isSq ? 'Dil' : 'Log out',
                style: const TextStyle(color: Colors.red)),
            onTap: onLogout,
          ),
        ],
      ),
    );
  }
}

class MyEventsPage extends StatefulWidget {
  final bool isSq;
  const MyEventsPage({super.key, required this.isSq});

  @override
  State<MyEventsPage> createState() => _MyEventsPageState();
}

class _MyEventsPageState extends State<MyEventsPage> {
  late Future<List<Event>> _future;

  @override
  void initState() {
    super.initState();
    _future = fetchEvents(onlyMine: true);
  }

  void _reload() {
    setState(() {
      _future = fetchEvents(onlyMine: true);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isSq = widget.isSq;

    return Scaffold(
      appBar: AppBar(
        title: Text(isSq ? 'Postimet e mia' : 'My Posts'),
        actions: [
          IconButton(onPressed: _reload, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: FutureBuilder<List<Event>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return Center(
                child: Text('${isSq ? "Gabim" : "Error"}: ${snapshot.error}'));

          final events = snapshot.data ?? [];
          if (events.isEmpty)
            return Center(
                child: Text(isSq
                    ? 'Nuk keni postuar asnjë event.'
                    : 'You have no posts.'));

          return ListView.builder(
            itemCount: events.length,
            itemBuilder: (context, index) {
              final event = events[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(event.title),
                  subtitle: Text('${event.date} • ${event.location}'),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) =>
                                EventDetailPage(event: event, isSq: isSq)));
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  final bool isSq;
  const ChatPage({super.key, required this.isSq});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();

  List<Message> _messages = [];
  Timer? _refreshTimer;

  bool _loading = true;
  bool _sending = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _refreshTimer = Timer.periodic(
        const Duration(seconds: 5), (_) => _loadMessages(showLoading: false));
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadMessages({bool showLoading = true}) async {
    if (showLoading && mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final messages = await fetchMessages();
      if (!mounted) return;
      setState(() {
        _messages = messages;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  Future<void> _send() async {
    final content = _messageController.text.trim();
    if (content.isEmpty || _sending) return;

    setState(() => _sending = true);

    try {
      await sendMessage(content);
      if (!mounted) return;
      _messageController.clear();
      await _loadMessages(showLoading: false);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Gabim: $e')));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isSq = widget.isSq;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat'),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: () => _loadMessages()),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? Center(
                        child: Text('${isSq ? "Gabim" : "Error"}: $_error',
                            textAlign: TextAlign.center))
                    : _messages.isEmpty
                        ? Center(
                            child: Text(isSq
                                ? 'Nuk ka mesazhe.'
                                : 'No messages available.'))
                        : ListView.builder(
                            reverse: true,
                            controller: _scrollController,
                            itemCount: _messages.length,
                            itemBuilder: (context, index) {
                              final msg = _messages[index];
                              final isMine = msg.isMine;

                              return Align(
                                alignment: isMine
                                    ? Alignment.centerRight
                                    : Alignment.centerLeft,
                                child: Container(
                                  margin: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 4),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: isMine
                                        ? Colors.blue.shade100
                                        : Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        msg.author,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            color: Colors.black87),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(msg.content,
                                          style: const TextStyle(
                                              color: Colors.black)),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText:
                          isSq ? 'Shkruaj një mesazh...' : 'Type a message...',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: _sending
                      ? const CircularProgressIndicator()
                      : const Icon(Icons.send),
                  onPressed: _send,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
