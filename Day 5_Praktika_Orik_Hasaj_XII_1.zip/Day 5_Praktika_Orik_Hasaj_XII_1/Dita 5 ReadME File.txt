                          Dita 5 ReadME File

                             BGT Campus


Ky eshte aplikacioni BGT Campus i zhvilluar me Flutter dhe Supabase per detyren perfundimtare te Dites 5. Aplikacioni ofron nje platforme te plote per menaxhimin e aktiviteteve studentore dhe komunikimin ne kampus.

Funksionalitetet kryesore te projektit

Autentikimi i perdoruesve
Krijimi i llogarise se re dhe kyçja ne aplikacion duke perdorur Supabase Auth ne menyre te sigurt.

Menaxhimi i eventeve
Përdoruesit mund te shohin listen e eventeve ne Ballina si dhe te faqja e eventeve. Ata mund te shtoje evente te reja ose te fshijne vetem eventet qe i kane krijuar vete.

Sistemi i pelqimeve dhe votimeve
Çdo event ka butonin per pelqime (Likes) te cilat ruhen ne kohe reale. Gjithashtu ekziston tab-i i sondazheve ku perdoruesit mund te krijojne pyetje te reja me opsione dhe te votojne ne menyre direkte.

Chat ne kohe reale
Sistemi i mesazheve live ku perdoruesit mund te shkruajne dhe te lexojne mesazhet e te gjitheve me rifreskim automatik.

Konfigurimi i UI
Aplikacioni mbeshtet nderrimin e temes nga Light Mode ne Dark Mode si dhe nderrimin e gjuhes nga Shqip ne Anglisht te profili.

Siguria ne Supabase
Zbatimi i politikave te sigurise RLS (Row Level Security) per tabelat e mesazheve dhe votave per te mbrojtur te dhenat.

Përmbajtja e dosjes

main.dart - Kodi kryesor i aplikacionit ne Flutter ku perfshihet e gjithe logjika e UI dhe thirrjet me API.
Day5_SQL.txt - Kodi SQL me strukturen e tabelave dhe politikat RLS te perdorura ne Supabase.
README.md - Dokumentacioni dhe pershkrimi i detajuar i projektit.